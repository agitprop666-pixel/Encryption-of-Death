from __future__ import annotations

import sys
import os
import time
import base64
import hashlib
import json
import hmac
import gzip
import secrets
import shutil
from pathlib import Path
from typing import List, Optional
from datetime import datetime

# --- PyQt6 Imports ---
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QSettings
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QDragEnterEvent, QDropEvent
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QTextEdit, QFileDialog,
    QProgressBar, QMessageBox, QSplashScreen, QRadioButton, QButtonGroup,
    QCheckBox, QGroupBox, QMenuBar, QMenu, QDialog, QDialogButtonBox,
    QListWidget, QListWidgetItem, QComboBox, QSpinBox
)

# --- Cryptography Imports ---
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

# --- Global Definitions ---
APP_NAME = "Encryption of Death"
ORG_NAME = "Death's Head Software"
VERSION = "2.0.0"

# =============================================================================
# Splash Screen Function
# =============================================================================

def create_splash():
    """Creates the QSplashScreen with dark theme and skull ASCII art."""
    try:
        splash_path = Path(__file__).parent / "splash.png"
        
        if splash_path.exists():
            # Load external splash.png
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            # Scale to 800x600 if needed
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                     Qt.TransformationMode.SmoothTransformation)
            
            # Add text overlay
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate splash with ASCII art
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
            
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Password Generator Dialog
# =============================================================================

class PasswordGeneratorDialog(QDialog):
    """Dialog for generating strong passwords."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Password Generator")
        self.setModal(True)
        self.generated_password = ""
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Length selector
        length_layout = QHBoxLayout()
        length_layout.addWidget(QLabel("Password Length:"))
        self.length_spin = QSpinBox()
        self.length_spin.setMinimum(12)
        self.length_spin.setMaximum(64)
        self.length_spin.setValue(24)
        length_layout.addWidget(self.length_spin)
        length_layout.addStretch()
        layout.addLayout(length_layout)
        
        # Character options
        self.use_uppercase = QCheckBox("Uppercase Letters (A-Z)")
        self.use_lowercase = QCheckBox("Lowercase Letters (a-z)")
        self.use_digits = QCheckBox("Digits (0-9)")
        self.use_special = QCheckBox("Special Characters (!@#$%^&*)")
        
        self.use_uppercase.setChecked(True)
        self.use_lowercase.setChecked(True)
        self.use_digits.setChecked(True)
        self.use_special.setChecked(True)
        
        layout.addWidget(self.use_uppercase)
        layout.addWidget(self.use_lowercase)
        layout.addWidget(self.use_digits)
        layout.addWidget(self.use_special)
        
        # Generated password display
        layout.addWidget(QLabel("Generated Password:"))
        self.password_display = QLineEdit()
        self.password_display.setReadOnly(True)
        layout.addWidget(self.password_display)
        
        # Buttons
        btn_layout = QHBoxLayout()
        generate_btn = QPushButton("Generate")
        generate_btn.clicked.connect(self.generate_password)
        copy_btn = QPushButton("Copy to Clipboard")
        copy_btn.clicked.connect(self.copy_to_clipboard)
        btn_layout.addWidget(generate_btn)
        btn_layout.addWidget(copy_btn)
        layout.addLayout(btn_layout)
        
        # Dialog buttons
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        self.generate_password()
    
    def generate_password(self):
        """Generate a secure random password."""
        charset = ""
        if self.use_uppercase.isChecked():
            charset += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        if self.use_lowercase.isChecked():
            charset += "abcdefghijklmnopqrstuvwxyz"
        if self.use_digits.isChecked():
            charset += "0123456789"
        if self.use_special.isChecked():
            charset += "!@#$%^&*()-_=+[]{}|;:,.<>?"
        
        if not charset:
            QMessageBox.warning(self, "Error", "Please select at least one character type.")
            return
        
        length = self.length_spin.value()
        self.generated_password = ''.join(secrets.choice(charset) for _ in range(length))
        self.password_display.setText(self.generated_password)
    
    def copy_to_clipboard(self):
        """Copy password to clipboard."""
        if self.generated_password:
            QApplication.clipboard().setText(self.generated_password)
            QMessageBox.information(self, "Copied", "Password copied to clipboard!")

# =============================================================================
# Recovery Key Dialog
# =============================================================================

class RecoveryKeyDialog(QDialog):
    """Dialog for displaying and saving recovery key."""
    
    def __init__(self, recovery_key: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Recovery Key")
        self.setModal(True)
        self.recovery_key = recovery_key
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        warning = QLabel("⚠️ IMPORTANT: Save this recovery key securely!\nYou will need it to decrypt files if you forget your password.")
        warning.setWordWrap(True)
        warning.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        layout.addWidget(warning)
        
        self.key_display = QTextEdit()
        self.key_display.setReadOnly(True)
        self.key_display.setPlainText(self.recovery_key)
        self.key_display.setMinimumHeight(100)
        layout.addWidget(self.key_display)
        
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Save to File")
        save_btn.clicked.connect(self.save_to_file)
        copy_btn = QPushButton("Copy to Clipboard")
        copy_btn.clicked.connect(self.copy_to_clipboard)
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(copy_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
    
    def save_to_file(self):
        """Save recovery key to a file."""
        filename, _ = QFileDialog.getSaveFileName(self, "Save Recovery Key", "recovery_key.txt", "Text Files (*.txt)")
        if filename:
            try:
                with open(filename, 'w') as f:
                    f.write(f"Encryption of Death - Recovery Key\n")
                    f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                    f.write(f"\n{self.recovery_key}\n")
                QMessageBox.information(self, "Success", "Recovery key saved successfully!")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save recovery key: {str(e)}")
    
    def copy_to_clipboard(self):
        """Copy recovery key to clipboard."""
        QApplication.clipboard().setText(self.recovery_key)
        QMessageBox.information(self, "Copied", "Recovery key copied to clipboard!")

# =============================================================================
# Encryption/Decryption Worker Thread
# =============================================================================

class CryptoWorker(QThread):
    """Worker thread for encryption/decryption operations."""
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)
    
    def __init__(self, files: List[str], password: str, mode: str, options: dict, parent=None):
        super().__init__(parent)
        self.files = files
        self.password = password
        self.mode = mode  # 'encrypt' or 'decrypt'
        self.options = options
        
    def derive_key(self, password: str, salt: bytes) -> bytes:
        """Derive a 256-bit key from password using PBKDF2."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        return kdf.derive(password.encode())
    
    def secure_delete(self, filepath: str, passes: int = 3):
        """Securely delete a file by overwriting it."""
        try:
            file_size = os.path.getsize(filepath)
            with open(filepath, 'ba+') as f:
                for _ in range(passes):
                    f.seek(0)
                    f.write(os.urandom(file_size))
                    f.flush()
                    os.fsync(f.fileno())
            os.remove(filepath)
        except Exception as e:
            self.progress.emit(0, f"Warning: Could not securely delete {Path(filepath).name}")
    
    def compute_hmac(self, data: bytes, key: bytes) -> bytes:
        """Compute HMAC-SHA256 for data integrity."""
        return hmac.new(key, data, hashlib.sha256).digest()
    
    def encrypt_file(self, filepath: str) -> bool:
        """Encrypt a single file using AES-256-CBC."""
        try:
            # Generate random salt and IV
            salt = os.urandom(16)
            iv = os.urandom(16)
            key = self.derive_key(self.password, salt)
            
            # Read file data
            with open(filepath, 'rb') as f:
                data = f.read()
            
            # Compress if enabled
            if self.options.get('compress', False):
                data = gzip.compress(data)
            
            # Pad data to block size
            padder = padding.PKCS7(128).padder()
            padded_data = padder.update(data) + padder.finalize()
            
            # Encrypt
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            encryptor = cipher.encryptor()
            encrypted_data = encryptor.update(padded_data) + encryptor.finalize()
            
            # Compute HMAC for integrity
            hmac_value = self.compute_hmac(salt + iv + encrypted_data, key)
            
            # Create metadata
            metadata = {
                'version': VERSION,
                'compressed': self.options.get('compress', False),
                'timestamp': datetime.now().isoformat(),
                'original_name': Path(filepath).name
            }
            metadata_json = json.dumps(metadata).encode('utf-8')
            metadata_length = len(metadata_json).to_bytes(4, 'big')
            
            # Write encrypted file with .enc extension
            output_path = filepath + '.enc'
            
            with open(output_path, 'wb') as f:
                f.write(b'EOD1')  # Magic bytes
                f.write(metadata_length)
                f.write(metadata_json)
                f.write(salt)
                f.write(iv)
                f.write(encrypted_data)
                f.write(hmac_value)
            
            # Secure delete original if enabled
            if self.options.get('shred_original', False):
                self.secure_delete(filepath)
            
            return True
        except Exception as e:
            self.progress.emit(0, f"Error encrypting {Path(filepath).name}: {str(e)}")
            return False
    
    def decrypt_file(self, filepath: str) -> bool:
        """Decrypt a single file encrypted with AES-256-CBC."""
        try:
            # Read encrypted file
            with open(filepath, 'rb') as f:
                file_content = f.read()
            
            # Check minimum file size
            if len(file_content) < 60:  # Magic + metadata_len + min metadata + salt + IV + HMAC
                raise ValueError("File too short - not a valid encrypted file")
            
            # Check magic bytes
            if file_content[:4] != b'EOD1':
                raise ValueError("Invalid file format - not an Encryption of Death file")
            
            # Read metadata length
            metadata_length = int.from_bytes(file_content[4:8], 'big')
            
            # Validate metadata length
            if metadata_length > 10000 or metadata_length < 10:
                raise ValueError("Invalid metadata length - file may be corrupted")
            
            # Read metadata
            metadata_start = 8
            metadata_end = metadata_start + metadata_length
            
            if len(file_content) < metadata_end + 64:  # + salt + IV + min encrypted + HMAC
                raise ValueError("File corrupted - incomplete data")
            
            metadata_json = file_content[metadata_start:metadata_end]
            
            try:
                metadata = json.loads(metadata_json.decode('utf-8'))
            except Exception as e:
                raise ValueError(f"Invalid metadata - {str(e)}")
            
            # Read salt and IV
            salt_start = metadata_end
            iv_start = salt_start + 16
            encrypted_start = iv_start + 16
            
            salt = file_content[salt_start:iv_start]
            iv = file_content[iv_start:encrypted_start]
            
            # Extract HMAC (last 32 bytes) and encrypted data
            encrypted_data = file_content[encrypted_start:-32]
            stored_hmac = file_content[-32:]
            
            if len(encrypted_data) == 0:
                raise ValueError("No encrypted data found")
            
            # Derive key
            key = self.derive_key(self.password, salt)
            
            # Verify HMAC
            computed_hmac = self.compute_hmac(salt + iv + encrypted_data, key)
            if not hmac.compare_digest(stored_hmac, computed_hmac):
                raise ValueError("Authentication failed - incorrect password or file has been tampered with")
            
            # Decrypt
            cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
            decryptor = cipher.decryptor()
            
            try:
                padded_data = decryptor.update(encrypted_data) + decryptor.finalize()
            except Exception as e:
                raise ValueError(f"Decryption failed - {str(e)}")
            
            # Unpad
            try:
                unpadder = padding.PKCS7(128).unpadder()
                data = unpadder.update(padded_data) + unpadder.finalize()
            except Exception as e:
                raise ValueError(f"Unpadding failed - file may be corrupted")
            
            # Decompress if needed
            if metadata.get('compressed', False):
                try:
                    data = gzip.decompress(data)
                except Exception as e:
                    raise ValueError(f"Decompression failed - {str(e)}")
            
            # Determine output path
            if filepath.endswith('.enc'):
                output_path = filepath[:-4]
            else:
                output_path = filepath + '.dec'
            
            # Use original name if available
            if 'original_name' in metadata:
                output_path = str(Path(filepath).parent / metadata['original_name'])
            
            # Write decrypted file
            with open(output_path, 'wb') as f:
                f.write(data)
            
            # Secure delete encrypted file if enabled
            if self.options.get('shred_original', False):
                self.secure_delete(filepath)
            
            return True
            
        except Exception as e:
            error_msg = str(e)
            self.progress.emit(0, f"Error decrypting {Path(filepath).name}: {error_msg}")
            return False
    
    def process_path(self, path: str) -> List[str]:
        """Recursively get all files from a path (file or directory)."""
        files = []
        p = Path(path)
        if p.is_file():
            files.append(str(p))
        elif p.is_dir():
            for item in p.rglob('*'):
                if item.is_file():
                    # When encrypting, skip already encrypted files
                    if self.mode == 'encrypt' and str(item).endswith('.enc'):
                        continue
                    # When decrypting, only process encrypted files
                    if self.mode == 'decrypt' and not str(item).endswith('.enc'):
                        continue
                    files.append(str(item))
        return files
    
    def run(self):
        """Execute the encryption/decryption operation."""
        try:
            # Collect all files to process
            all_files = []
            for path in self.files:
                processed_files = self.process_path(path)
                all_files.extend(processed_files)
            
            if not all_files:
                self.finished.emit(False, "No files to process. Check if folder contains valid files.")
                return
            
            total = len(all_files)
            successful = 0
            failed = 0
            
            for idx, filepath in enumerate(all_files):
                filename = Path(filepath).name
                self.progress.emit(int((idx / total) * 100), f"Processing {filename}...")
                
                try:
                    if self.mode == 'encrypt':
                        if self.encrypt_file(filepath):
                            successful += 1
                        else:
                            failed += 1
                    else:  # decrypt
                        if self.decrypt_file(filepath):
                            successful += 1
                        else:
                            failed += 1
                except Exception as e:
                    self.progress.emit(0, f"Error: {str(e)}")
                    failed += 1
                
                time.sleep(0.02)
            
            self.progress.emit(100, "Complete!")
            
            if failed > 0:
                self.finished.emit(True, f"Processed {successful}/{total} files successfully, {failed} failed")
            else:
                self.finished.emit(True, f"Successfully processed {successful}/{total} files")
            
        except Exception as e:
            self.finished.emit(False, f"Operation failed: {str(e)}")

# =============================================================================
# Main Window
# =============================================================================

class EncryptionApp(QMainWindow):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        self.dark_mode = True
        self.files_to_process = []
        self.worker = None
        self.settings = QSettings(ORG_NAME, APP_NAME)
        self.load_settings()
        self.init_ui()
        self.apply_theme()
        self.load_recent_files()
        
    def init_ui(self):
        """Initialize the user interface."""
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")
        self.setGeometry(100, 100, 900, 700)
        self.setAcceptDrops(True)
        
        # Menu bar
        self.create_menu_bar()
        
        # Central widget
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)
        
        # Title
        title = QLabel(APP_NAME)
        title.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title)
        
        # Mode selection
        mode_layout = QHBoxLayout()
        mode_label = QLabel("Operation Mode:")
        mode_label.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        self.encrypt_radio = QRadioButton("Encrypt")
        self.decrypt_radio = QRadioButton("Decrypt")
        self.encrypt_radio.setChecked(True)
        mode_group = QButtonGroup(self)
        mode_group.addButton(self.encrypt_radio)
        mode_group.addButton(self.decrypt_radio)
        self.encrypt_radio.toggled.connect(self.update_options_visibility)
        mode_layout.addWidget(mode_label)
        mode_layout.addWidget(self.encrypt_radio)
        mode_layout.addWidget(self.decrypt_radio)
        mode_layout.addStretch()
        main_layout.addLayout(mode_layout)
        
        # Password input with generator
        pwd_layout = QHBoxLayout()
        pwd_label = QLabel("Password:")
        pwd_label.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        self.password_input = QLineEdit()
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_input.setPlaceholderText("Enter encryption password")
        self.password_input.setMinimumHeight(30)
        self.password_input.textChanged.connect(self.update_password_strength)
        self.show_password_btn = QPushButton("👁")
        self.show_password_btn.setMaximumWidth(40)
        self.show_password_btn.clicked.connect(self.toggle_password_visibility)
        self.generate_pwd_btn = QPushButton("Generate")
        self.generate_pwd_btn.clicked.connect(self.show_password_generator)
        pwd_layout.addWidget(pwd_label)
        pwd_layout.addWidget(self.password_input)
        pwd_layout.addWidget(self.show_password_btn)
        pwd_layout.addWidget(self.generate_pwd_btn)
        main_layout.addLayout(pwd_layout)
        
        # Password strength indicator
        self.strength_label = QLabel("Password Strength: None")
        self.strength_label.setFont(QFont("Arial", 9))
        main_layout.addWidget(self.strength_label)
        
        # Options group box
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout()
        
        self.compress_check = QCheckBox("Compress before encryption (reduces file size)")
        self.shred_check = QCheckBox("Securely delete original files after processing")
        self.hmac_check = QCheckBox("Enable integrity verification (HMAC)")
        self.hmac_check.setChecked(True)
        self.hmac_check.setEnabled(False)  # Always enabled
        
        options_layout.addWidget(self.compress_check)
        options_layout.addWidget(self.shred_check)
        options_layout.addWidget(self.hmac_check)
        
        options_group.setLayout(options_layout)
        main_layout.addWidget(options_group)
        
        # File selection buttons
        btn_layout = QHBoxLayout()
        self.select_files_btn = QPushButton("Select Files")
        self.select_folder_btn = QPushButton("Select Folder")
        self.clear_btn = QPushButton("Clear")
        self.recent_btn = QPushButton("Recent Locations")
        self.select_files_btn.setMinimumHeight(35)
        self.select_folder_btn.setMinimumHeight(35)
        self.clear_btn.setMinimumHeight(35)
        self.recent_btn.setMinimumHeight(35)
        self.select_files_btn.clicked.connect(self.select_files)
        self.select_folder_btn.clicked.connect(self.select_folder)
        self.clear_btn.clicked.connect(self.clear_files)
        self.recent_btn.clicked.connect(self.show_recent_locations)
        btn_layout.addWidget(self.select_files_btn)
        btn_layout.addWidget(self.select_folder_btn)
        btn_layout.addWidget(self.recent_btn)
        btn_layout.addWidget(self.clear_btn)
        main_layout.addLayout(btn_layout)
        
        # Drop zone
        drop_label = QLabel("Drag & Drop Files/Folders Here")
        drop_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        drop_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        drop_label.setMinimumHeight(60)
        drop_label.setFrameStyle(2)
        main_layout.addWidget(drop_label)
        
        # Files list
        list_label = QLabel("Files to Process:")
        list_label.setFont(QFont("Arial", 10, QFont.Weight.Bold))
        main_layout.addWidget(list_label)
        
        self.files_display = QTextEdit()
        self.files_display.setReadOnly(True)
        self.files_display.setMaximumHeight(100)
        main_layout.addWidget(self.files_display)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimumHeight(25)
        main_layout.addWidget(self.progress_bar)
        
        # Status label
        self.status_label = QLabel("Ready")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.status_label.setFont(QFont("Arial", 10))
        main_layout.addWidget(self.status_label)
        
        # Process button
        self.process_btn = QPushButton("START")
        self.process_btn.setMinimumHeight(45)
        self.process_btn.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        self.process_btn.clicked.connect(self.start_process)
        main_layout.addWidget(self.process_btn)
        
        main_layout.addStretch()
    
    def create_menu_bar(self):
        """Create the menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        recent_action = file_menu.addAction("Recent Locations")
        recent_action.triggered.connect(self.show_recent_locations)
        
        file_menu.addSeparator()
        
        exit_action = file_menu.addAction("Exit")
        exit_action.triggered.connect(self.close)
        
        # View menu
        view_menu = menubar.addMenu("View")
        
        light_mode_action = view_menu.addAction("Light Mode")
        light_mode_action.setCheckable(True)
        light_mode_action.triggered.connect(lambda: self.set_theme(False))
        
        dark_mode_action = view_menu.addAction("Dark Mode")
        dark_mode_action.setCheckable(True)
        dark_mode_action.triggered.connect(lambda: self.set_theme(True))
        
        # Set initial checked state
        if self.dark_mode:
            dark_mode_action.setChecked(True)
        else:
            light_mode_action.setChecked(True)
        
        self.light_mode_action = light_mode_action
        self.dark_mode_action = dark_mode_action
        
        # Tools menu
        tools_menu = menubar.addMenu("Tools")
        
        pwd_gen_action = tools_menu.addAction("Password Generator")
        pwd_gen_action.triggered.connect(self.show_password_generator)
        
        tools_menu.addSeparator()
        
        clear_recent_action = tools_menu.addAction("Clear Recent History")
        clear_recent_action.triggered.connect(self.clear_recent_files)
    
    def load_settings(self):
        """Load application settings."""
        self.dark_mode = self.settings.value('dark_mode', True, type=bool)
    
    def save_settings(self):
        """Save application settings."""
        self.settings.setValue('dark_mode', self.dark_mode)
    
    def load_recent_files(self):
        """Load recent file locations."""
        recent = self.settings.value('recent_locations', [], type=list)
        self.recent_locations = recent[:10]  # Keep only last 10
    
    def add_recent_location(self, path: str):
        """Add a location to recent history."""
        if path in self.recent_locations:
            self.recent_locations.remove(path)
        self.recent_locations.insert(0, path)
        self.recent_locations = self.recent_locations[:10]
        self.settings.setValue('recent_locations', self.recent_locations)
    
    def show_recent_locations(self):
        """Show dialog with recent locations."""
        dialog = QDialog(self)
        dialog.setWindowTitle("Recent Locations")
        dialog.setModal(True)
        layout = QVBoxLayout(dialog)
        
        list_widget = QListWidget()
        for location in self.recent_locations:
            item = QListWidgetItem(location)
            list_widget.addItem(item)
        
        if not self.recent_locations:
            list_widget.addItem("No recent locations")
        
        list_widget.itemDoubleClicked.connect(lambda item: self.load_recent_location(item.text(), dialog))
        layout.addWidget(list_widget)
        
        btn_layout = QHBoxLayout()
        load_btn = QPushButton("Load Selected")
        load_btn.clicked.connect(lambda: self.load_recent_location(
            list_widget.currentItem().text() if list_widget.currentItem() else None, dialog))
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.accept)
        btn_layout.addWidget(load_btn)
        btn_layout.addWidget(close_btn)
        layout.addLayout(btn_layout)
        
        dialog.exec()
    
    def load_recent_location(self, path: Optional[str], dialog: QDialog):
        """Load a recent location."""
        if path and path != "No recent locations" and os.path.exists(path):
            if path not in self.files_to_process:
                self.files_to_process.append(path)
            self.update_files_display()
            dialog.accept()
        elif path:
            QMessageBox.warning(self, "Error", "Location no longer exists")
    
    def clear_recent_files(self):
        """Clear recent files history."""
        reply = QMessageBox.question(self, "Confirm", 
            "Clear all recent locations history?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.recent_locations = []
            self.settings.setValue('recent_locations', [])
            QMessageBox.information(self, "Success", "Recent history cleared")
    
    def update_options_visibility(self):
        """Update visibility of encryption-only options."""
        is_encrypt = self.encrypt_radio.isChecked()
        self.compress_check.setEnabled(is_encrypt)
    
    def toggle_password_visibility(self):
        """Toggle password visibility."""
        if self.password_input.echoMode() == QLineEdit.EchoMode.Password:
            self.password_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.show_password_btn.setText("🔒")
        else:
            self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.show_password_btn.setText("👁")
    
    def show_password_generator(self):
        """Show password generator dialog."""
        dialog = PasswordGeneratorDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.password_input.setText(dialog.generated_password)
    
    def update_password_strength(self):
        """Update password strength indicator."""
        password = self.password_input.text()
        if not password:
            self.strength_label.setText("Password Strength: None")
            return
        
        score = 0
        if len(password) >= 8:
            score += 1
        if len(password) >= 12:
            score += 1
        if len(password) >= 16:
            score += 1
        if any(c.islower() for c in password):
            score += 1
        if any(c.isupper() for c in password):
            score += 1
        if any(c.isdigit() for c in password):
            score += 1
        if any(c in "!@#$%^&*()-_=+[]{}|;:,.<>?" for c in password):
            score += 1
        
        if score <= 2:
            strength = "Weak"
            color = "red"
        elif score <= 4:
            strength = "Medium"
            color = "orange"
        elif score <= 6:
            strength = "Strong"
            color = "green"
        else:
            strength = "Very Strong"
            color = "darkgreen"
        
        self.strength_label.setText(f"Password Strength: {strength}")
    
    def apply_theme(self):
        """Apply the current theme (light or dark)."""
        if self.dark_mode:
            bg = QColor(30, 30, 30)
            fg = QColor(240, 240, 240)
            input_bg = QColor(255, 255, 255)
            input_fg = QColor(20, 20, 20)
            button_bg = QColor(200, 200, 200)
            button_fg = QColor(20, 20, 20)
            accent = QColor(120, 0, 0)
        else:
            bg = QColor(240, 240, 240)
            fg = QColor(20, 20, 20)
            input_bg = QColor(255, 255, 255)
            input_fg = QColor(20, 20, 20)
            button_bg = QColor(220, 220, 220)
            button_fg = QColor(20, 20, 20)
            accent = QColor(180, 0, 0)
        
        palette = self.palette()
        palette.setColor(palette.ColorRole.Window, bg)
        palette.setColor(palette.ColorRole.WindowText, fg)
        palette.setColor(palette.ColorRole.Base, input_bg)
        palette.setColor(palette.ColorRole.AlternateBase, button_bg)
        palette.setColor(palette.ColorRole.Text, input_fg)
        palette.setColor(palette.ColorRole.Button, button_bg)
        palette.setColor(palette.ColorRole.ButtonText, button_fg)
        palette.setColor(palette.ColorRole.Highlight, accent)
        palette.setColor(palette.ColorRole.HighlightedText, QColor(255, 255, 255))
        palette.setColor(palette.ColorRole.PlaceholderText, QColor(120, 120, 120))
        
        self.setPalette(palette)
        QApplication.instance().setPalette(palette)
    
    def toggle_theme(self):
        """Toggle between light and dark mode."""
        self.dark_mode = self.dark_radio.isChecked()
        self.save_settings()
        self.apply_theme()
    
    def set_theme(self, dark: bool):
        """Set theme from menu."""
        self.dark_mode = dark
        self.light_mode_action.setChecked(not dark)
        self.dark_mode_action.setChecked(dark)
        self.save_settings()
        self.apply_theme()
    
    def dragEnterEvent(self, event: QDragEnterEvent):
        """Handle drag enter event."""
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
    
    def dropEvent(self, event: QDropEvent):
        """Handle drop event."""
        urls = event.mimeData().urls()
        for url in urls:
            path = url.toLocalFile()
            if path and path not in self.files_to_process:
                self.files_to_process.append(path)
                self.add_recent_location(path)
        self.update_files_display()
    
    def select_files(self):
        """Open file dialog to select files."""
        files, _ = QFileDialog.getOpenFileNames(self, "Select Files")
        for f in files:
            if f not in self.files_to_process:
                self.files_to_process.append(f)
                self.add_recent_location(f)
        self.update_files_display()
    
    def select_folder(self):
        """Open folder dialog to select a folder."""
        folder = QFileDialog.getExistingDirectory(self, "Select Folder")
        if folder and folder not in self.files_to_process:
            self.files_to_process.append(folder)
            self.add_recent_location(folder)
        self.update_files_display()
    
    def clear_files(self):
        """Clear the files list."""
        self.files_to_process.clear()
        self.update_files_display()
        self.status_label.setText("Ready")
        self.progress_bar.setValue(0)
    
    def update_files_display(self):
        """Update the files display text."""
        if self.files_to_process:
            text = "\n".join([Path(f).name if Path(f).is_file() else f"{Path(f).name}/" for f in self.files_to_process])
            self.files_display.setText(text)
        else:
            self.files_display.setText("No files selected")
    
    def start_process(self):
        """Start the encryption/decryption process."""
        if not self.files_to_process:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("No Files")
            msg_box.setText("Please select files or folders to process.")
            msg_box.setIcon(QMessageBox.Icon.Warning)
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            msg_box.exec()
            return
        
        password = self.password_input.text()
        if not password:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("No Password")
            msg_box.setText("Please enter a password.")
            msg_box.setIcon(QMessageBox.Icon.Warning)
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            msg_box.exec()
            return
        
        if len(password) < 8:
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Weak Password")
            msg_box.setText("Password is shorter than 8 characters. Continue anyway?")
            msg_box.setIcon(QMessageBox.Icon.Question)
            msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            if msg_box.exec() == QMessageBox.StandardButton.No:
                return
        
        mode = 'encrypt' if self.encrypt_radio.isChecked() else 'decrypt'
        
        # Confirm secure deletion if enabled
        if self.shred_check.isChecked():
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Confirm Secure Deletion")
            msg_box.setText("Original files will be securely deleted and cannot be recovered. Continue?")
            msg_box.setIcon(QMessageBox.Icon.Warning)
            msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            if msg_box.exec() == QMessageBox.StandardButton.No:
                return
        
        # Prepare options
        options = {
            'compress': self.compress_check.isChecked() and mode == 'encrypt',
            'shred_original': self.shred_check.isChecked()
        }
        
        # Disable UI during processing
        self.process_btn.setEnabled(False)
        self.select_files_btn.setEnabled(False)
        self.select_folder_btn.setEnabled(False)
        self.clear_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        
        # Start worker thread
        self.worker = CryptoWorker(self.files_to_process, password, mode, options)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.process_finished)
        self.worker.start()
    
    def update_progress(self, value: int, message: str):
        """Update progress bar and status."""
        self.progress_bar.setValue(value)
        self.status_label.setText(message)
    
    def process_finished(self, success: bool, message: str):
        """Handle process completion."""
        self.process_btn.setEnabled(True)
        self.select_files_btn.setEnabled(True)
        self.select_folder_btn.setEnabled(True)
        self.clear_btn.setEnabled(True)
        
        if success:
            # Create message box with proper styling
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Success")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Icon.Information)
            
            # Ensure text is visible by using a light palette for the dialog
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            msg_box.exec()
            
            # Clear files and password after successful processing
            self.clear_files()
            self.password_input.clear()
            self.update_password_strength()
        else:
            # Create error message box with proper styling
            msg_box = QMessageBox(self)
            msg_box.setWindowTitle("Error")
            msg_box.setText(message)
            msg_box.setIcon(QMessageBox.Icon.Critical)
            
            # Ensure text is visible
            dialog_palette = msg_box.palette()
            dialog_palette.setColor(dialog_palette.ColorRole.Window, QColor(240, 240, 240))
            dialog_palette.setColor(dialog_palette.ColorRole.WindowText, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.Text, QColor(20, 20, 20))
            dialog_palette.setColor(dialog_palette.ColorRole.ButtonText, QColor(20, 20, 20))
            msg_box.setPalette(dialog_palette)
            msg_box.exec()
        
        self.status_label.setText("Ready")
        self.progress_bar.setValue(0)
    
    def closeEvent(self, event):
        """Handle window close event."""
        self.save_settings()
        event.accept()

# =============================================================================
# Command Line Interface
# =============================================================================

def run_cli():
    """Run the command-line interface."""
    import argparse
    
    parser = argparse.ArgumentParser(description=f"{APP_NAME} - AES-256 File Encryption")
    parser.add_argument('files', nargs='+', help='Files or folders to process')
    parser.add_argument('-d', '--decrypt', action='store_true', help='Decrypt mode')
    parser.add_argument('-p', '--password', required=True, help='Encryption password')
    parser.add_argument('-c', '--compress', action='store_true', help='Compress before encryption')
    parser.add_argument('-s', '--shred', action='store_true', help='Securely delete original files')
    
    args = parser.parse_args()
    
    mode = 'decrypt' if args.decrypt else 'encrypt'
    options = {
        'compress': args.compress and mode == 'encrypt',
        'shred_original': args.shred
    }
    
    print(f"\n{APP_NAME} v{VERSION}")
    print(f"Mode: {mode.upper()}")
    print(f"Processing {len(args.files)} path(s)...\n")
    
    class CLIProgress:
        def emit(self, *args):
            if len(args) >= 2:
                print(f"[{args[0]}%] {args[1]}")
    
    class CLIWorker(CryptoWorker):
        def __init__(self, files, password, mode, options):
            super().__init__(files, password, mode, options, None)
            self.progress = CLIProgress()
    
    worker = CLIWorker(args.files, args.password, mode, options)
    worker.run()
    
    print("\nOperation complete!")

# =============================================================================
# Main Application Entry Point
# =============================================================================

def main():
    # Check if running in CLI mode
    if len(sys.argv) > 1 and '--cli' in sys.argv:
        sys.argv.remove('--cli')
        run_cli()
        return
    
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Create and show splash screen
    splash = create_splash()
    if splash:
        splash.show()
        
        messages = [
            "Initializing cryptographic modules...",
            "Loading security protocols...",
            "Preparing encryption engine...",
            "Ready to secure your files..."
        ]
        
        for i, msg in enumerate(messages):
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255)
            )
            app.processEvents()
            time.sleep(5.4 / len(messages))
    
    window = EncryptionApp()
    window.show()
    if splash:
        splash.finish(window)
    
    sys.exit(app.exec())

if __name__ == '__main__':
    main()